/* Skin Diary offline cache. After the first open, the whole app loads from the phone, no internet needed.
   Your diary itself (photos, notes, products) lives in the phone's app storage, never in this cache. */
const CACHE = 'skin-diary-8204ad4c30';
const FILES = [
  './',
  './index.html',
  './manifest.webmanifest',
  './fonts/fraunces.woff2',
  './icons/icon-v2-180.png',
  './icons/icon-v2-192.png',
  './icons/icon-v2-512.png',
  './icons/icon-v2-maskable-512.png',
  './splash/dark-1125x2436.png',
  './splash/dark-1170x2532.png',
  './splash/dark-1179x2556.png',
  './splash/dark-1206x2622.png',
  './splash/dark-1242x2208.png',
  './splash/dark-1242x2688.png',
  './splash/dark-1260x2736.png',
  './splash/dark-1284x2778.png',
  './splash/dark-1290x2796.png',
  './splash/dark-1320x2868.png',
  './splash/dark-750x1334.png',
  './splash/dark-828x1792.png',
  './splash/light-1125x2436.png',
  './splash/light-1170x2532.png',
  './splash/light-1179x2556.png',
  './splash/light-1206x2622.png',
  './splash/light-1242x2208.png',
  './splash/light-1242x2688.png',
  './splash/light-1260x2736.png',
  './splash/light-1284x2778.png',
  './splash/light-1290x2796.png',
  './splash/light-1320x2868.png',
  './splash/light-750x1334.png',
  './splash/light-828x1792.png'
];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(FILES)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k.startsWith('skin-diary-') && k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

// Cache first, so the app opens instantly and offline. Quietly refresh in the background when online.
self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== location.origin) return;
  e.respondWith((async () => {
    const cache = await caches.open(CACHE);
    const key = req.mode === 'navigate' ? './index.html' : req;
    const cached = await cache.match(key, { ignoreSearch: true });
    const network = fetch(req).then(res => {
      if (res && res.ok && res.type === 'basic') cache.put(key, res.clone());
      return res;
    }).catch(() => null);
    if (cached) { e.waitUntil(network); return cached; }
    return (await network) || new Response('Skin Diary is offline and this file was not saved yet.', { status: 503 });
  })());
});
